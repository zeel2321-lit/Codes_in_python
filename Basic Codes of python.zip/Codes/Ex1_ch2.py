num1=input("Enter number1:")
num2=input("Enter number2:")
num3=input("Enter number3:")
avg=(int(num1)+int(num2)+int(num3))/3
print(f"The average of\t{num1} ,{num2} ,{num3} is {avg}")
