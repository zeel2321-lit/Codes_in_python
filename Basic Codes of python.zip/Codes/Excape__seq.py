print("Hello \"world\" world")
#\"world\" is excape sequence
print('I \' m Zeel')
print("Line a\n line b\n line c")
print("line b\t line c")
#output : Line A\n Line b treat this as a normal text
print("Line A \\n Line B")
#output: \" \"
print(" \\\"\\\"")
# \' - ' (b)
# \\- \(a)
# \\\' - \'