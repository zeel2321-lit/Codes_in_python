
fruits =['orange','apple','pear','banana','kiwi']
if 'apple' in fruits:
    print("it is present")
else:
    print("It is not present")