print(3+2)
print(2/4) #float division
print(2//4) #integer division
print(2**3) #cube of 2
print(2**0.5)   #Sq root of 2
print(round (2**0.5,4))
