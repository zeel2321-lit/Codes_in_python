# center method 
#name = " Zeel"
# **Zeel**
#print(name.center(7,"*"))

name= input("Enter you name:")
print(name.center(len(name) + 8 ,"*"))
