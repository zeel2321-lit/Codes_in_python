#  count
fruits =['orange','apple','pear','kiwi','apple','banana']
print(fruits.count("apple"))

# sort methods
##if we want to arrange in alphabetical order
fruits.sort()
print(fruits)
numbers=[3,5,1,9,10]
numbers.sort()
print(numbers)
# sorted method
print(sorted(numbers))
# here sorted method just sort elements for that particular line

# reverse
# clear
numbers.clear()
print(numbers)
# copy
numbers_copy=numbers.copy()
print(numbers_copy)

