# default parameters

def user_info(fname,lname,age):
    print(f"Your first name is {fname}")
    print(f"Your last name is {lname}")
    print(f"your age is {age}")
 
user_info('zeel','janani','19')