# CHeck empty or not 
# name =" Zeel"
name =input("Enter your name :") 
if name: # true if string is not empty
    print(f"Your name is {name}")
else:
    print("you didn't type anything")