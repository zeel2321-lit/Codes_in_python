#       print this following lines      
# this is \\ backslash
# this is /\/\/\/\/\ mountian
# he is     awesome (use escape sequence)
# \" \n \t \' (print this as an output)
print("this is \\\\ backslash")
print("this is /\/\/\/\/\ mountian")
print("he is\t awesome")
print("\\\" \\n \\t \\\'")
#\"-"
#\\ - \
#\\\" - \"
#shortcut
print(r"Line a \n line b")
#here r is used as a normal text reader
