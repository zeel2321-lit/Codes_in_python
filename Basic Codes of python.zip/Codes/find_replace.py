# replace() and find() methodd
string = " She is intelligent"
print(string.replace(" ","_"))
print(string.replace("is","was",1))

# find method
print(string.find("is"))
# if we want to find particular thing 
 # print(string.find("is",1))
is_pst =string.find("is") # is_pst ----> number
is_pst1 =   

 
 