# infinite loop
# True
# Flase
# case sensitive
# for loop
# for loop with range function
 # range fun --->
for i in range(10):     # Range 0 to 9
    print("Hello Zeel")

# example 1
# sum from 1 to 10
total =0
for i in range(1,11):
    total =total + i
print(total)

n =int(input("Enter num :"))
sum =0
for i in range(1,n+1):
    sum += i
print(sum)

# exercise 2
 # sum of 1+2+5+6

# exercise 3
# count variable