name = "Zeel"
for i in range(len(name)):
    print(name[i])

# 1256 ----> 1+2+5+6+
num = int(input("Enter a num:"))
total =0
for i in range(0,num+1):
    total += i
print(total)