age = int(input(" Enter your age "))
if age >= 14:
    print("You are invited") 
else:
    print("oops!, you can't play")


