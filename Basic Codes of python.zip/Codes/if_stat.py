# syntax
 # if condition
 # if condition is true then this code will execute
age = int(input(" Enter your age "))
if age >= 14:
    print("You are invited") 