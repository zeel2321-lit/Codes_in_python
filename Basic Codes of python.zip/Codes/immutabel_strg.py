 # strings are immutable
string = "string" 
print(string[1])
 # string[1] ='T' it will not change cz it is immuatbale
print(string.replace('t','T')) # it will make another string
print(string) # it will not change 
# In python string is immuatbale
