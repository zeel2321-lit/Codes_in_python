# in keyword
name ="Zeel"
#if with in
if 'e' in name:
    print("it is there")
else:
    print("it is not there")