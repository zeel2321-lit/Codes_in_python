#name =input("Enter your name")
#input in one line
name , age = input("Enter your name  and age ").split(",")
print(name)
print(age)