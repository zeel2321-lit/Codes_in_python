number_one = int(input("Enter 1st number"))
number_two =int(input("Enter second number"))
total= number_one + number_two
print("total is"+ str(total))
#str
# 4---> "4"
 #int 
 # "4" ---> 4
 #float
 #"4" ---> 4.0
num1 =str(4)
num2 = float("44")
num3 =int("33")
print(num2 + num3)