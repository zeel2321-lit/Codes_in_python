# copare list
# == , is
fruits =['orange','apple','pear']
fruits3=['orange','apple','pear']
fruits2 =['banana','kiwi','apple','banana']
print(fruits==fruits2)
print(fruits==fruits3) # values are same
print(fruits is fruits3) # is keyword checks 
# if both the list are at the same memory then it will be true otherwise false
