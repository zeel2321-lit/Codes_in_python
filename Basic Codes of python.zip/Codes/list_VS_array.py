# list vs array
# array---> Ordered collection of items--> can store only one data type
# array module---> which we can import ---> bt can store only one datta type
# array module spped is good compre to list
# numpy array---> binding with c
# list----> ordered collection of items---> can streo multiple data type element
