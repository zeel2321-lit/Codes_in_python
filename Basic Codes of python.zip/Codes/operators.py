name = "Zeel"
name = name + "ll"
 # name += "ll"
print(name)
age = 19
age += 1
print(age)
