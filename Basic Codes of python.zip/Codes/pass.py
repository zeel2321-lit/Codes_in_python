# pass statement
x =18
if x > 18:
    # if we dn want to write anything then 
    pass