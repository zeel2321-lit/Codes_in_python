# return vs print
def add_three(a,b,c):
    return a+b+c
def add_th(a,b,c):
    print(a+b+c)
add_th(5,5,5)
add_three(5,5,5)

