from random import randrange


for i  in range(1,11):  #--> 1 start arg 11 end arg
    print(i)
for i in range(0,11,2):
    print(i)
 # for reversing
for i in range(10,0,-1):
    print(i)
for i in range(0,-11,-1):
    print(i)