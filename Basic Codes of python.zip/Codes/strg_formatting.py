name= "Zeel"
age = 19
print("Hello"+ name + "Your age is" + str(age))
#print("Hello"+ name + "Your age is" + age) #error
#string formatting
# python 2
# pyhton 3
# python 3.6 best
print("Hello {} your age is {} " .format(name,age))
#3.6
print(f"hello {name} your age is {age+2}") #clean formating