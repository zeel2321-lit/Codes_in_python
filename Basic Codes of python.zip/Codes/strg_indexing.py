#sring indexing
language = "python"
#position(index number)
#p=0,-6
#y=1,-5
#t=2,-4
#h=3,-3
#0= 4,-2
#n=5,-1
print(language[-6])
