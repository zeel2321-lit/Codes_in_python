#slicing/ Selecting sub sequence
lang="Python"
#print(lang[4])
# syntax -[start argument:stop argument-1]
print(lang[2:6])
print(lang[:])
print(lang[1:])
print(lang[:1])