# string methods part 1

name = "Zeel JANANi"

# 1. len() function
# length = len(name)
#print(length)
print(len(name))
# counts space also

# 2. lower() method
print(name.lower())


# 3. upper() method
print(name.upper())

# 4. title () method

print(name.title())

# count() method

print(name.count("e"))