#Strings- Collection of characters inside single quotes or double quotes
first_name="Zeel"
Last_name="janani"
full_name= first_name +" "+ Last_name
print(full_name)
#print(first_name + 3)// error
print(first_name + "3") #no error
print(first_name + str(3)) #no error
print(first_name * 3)