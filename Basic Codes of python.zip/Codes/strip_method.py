# problem to solve spacing 
name = "     Ze   eeel      "
dots = ".................."
# to remove left space
# lstrip() method
print(name +dots)
print(name.lstrip() + dots)
print(name.rstrip() + dots)
print(name.strip() + dots)
 # strip wont replace inbetween space
print(name.replace(" ","") +dots)
