# Tuple is a data structure
# tuple can store any data type
# most important tuple are immutable, once tuple is created we can't update it latet
# i men data insidet the tuple
# here in tuple we use () brackets

example = ('one','two','three')
# no append, no insert , no pop , no remove
# we use tuple when we know there is no need of any changes in the data
# tuples are faster than lists

days =('monday','tuesday')

# methods we use in tuple
# count, index , len function , slicing  ---> 
print(example)