#user input
# input function
name =input("Writte your name")
print( "Hello" + name)
age = input("what is your age?")
# 19 ,"19"
print("Your age is " + age)