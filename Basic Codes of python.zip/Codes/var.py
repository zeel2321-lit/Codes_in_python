number1=2
print(number1)
number1=4
print(number1)
name="Zeel"
print(name)
name =123
print(name)
#this is called dynamic programming language
#rules of variable naming
#rule1- cannot start with a number
# 1number=4
#rule2- can start with any letter or _
#_name="ZEEL"
#3RULE :-cannot use special symbol
#naming conventions for variables
user_1_name="Zeel"
print(user_1_name)
#snake case writing _ Used in python in google
#xamel case writing
userOneName="meeta" #used in java

