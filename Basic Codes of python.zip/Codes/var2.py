name , age ="Zeel","19"
print("Hello" + name +" your age is "+ age)
x=y=z=1
print(x+y+z)