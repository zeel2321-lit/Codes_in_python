# loops
# while loop , for loop
i =1 
while i<=10:
    print("hello world") 
    i=i+1
# sum :1 to 10 num
total=0
i=1
while i<=10:
    total =total + i
    i=i+1
print(total)

# exercise one of three
# sum of n natural num
# ask a user for natural num
 # print total from 1 to n
num = int(input("Enter number :"))
t= 0
j=0
while j<=num:
    t = t+j
    j=j+1
print(t)


