dictA={'Name':'Zeel',
        'Student ID':'032',
        'Date of birth':'21',
        'Month of birth':'03',
        'Year of birth':'2001',
        'Name of the college':'Marwadi University',
        'SPI in sem 1':'8.95',
        'SPI in Sem 2':'7',
        'SPI in sem 3':'8.86'}
print(dictA)
dictA['Expected result in sem 4']=9.0
print(dictA)