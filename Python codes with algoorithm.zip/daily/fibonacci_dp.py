# -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 12:28:27 2021

@author: Zeel janani
"""


# Fibonacci Series using Dynamic Programming
def fibonacci(n):
     
    # Taking 1st two fibonacci nubers as 0 and 1
    f = [0, 1]
     
     
    for i in range(2, n+1):
        f.append(f[i-1] + f[i-2])
    return f[n]
     
print(fibonacci(9))