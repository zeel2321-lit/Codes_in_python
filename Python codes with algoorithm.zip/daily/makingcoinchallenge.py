def makingcoinchallenege(coin,amt):
    table[0 for i in range (amt+1)]
    table[0]   





coin=[2,3,5,10]
amt=15
makingcoinchallenge(coin,amt)